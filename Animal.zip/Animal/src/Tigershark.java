public class Tigershark extends Animal {
    public static void eat(){
        System.out.println("Tigersharks eat meat...");
    }
    public static void move(){
        System.out.println("I swim fast");
    }
}
