public class Jellyfish extends Animal {
    public static void eat(){
        System.out.println("Jellyfish eat fish...");
    }
    public static void move(){
        System.out.println("I swim");
    }
}

