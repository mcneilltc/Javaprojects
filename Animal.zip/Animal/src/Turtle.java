public class Turtle  extends Animal{
    public static void eat(){
        System.out.println("Turtles eat fish...");
    }
public static void sleep() {
    System.out.println("I sleep in my shell");
}
    public static void move(){
        System.out.println("I walk slow");
    }
}
