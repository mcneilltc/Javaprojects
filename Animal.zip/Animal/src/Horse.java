public class Horse extends Animal {
    public static void eat(){
        System.out.println("Horses eat grass...");
    }
    public static void move(){
        System.out.println("I gallop fast");
    }
}
