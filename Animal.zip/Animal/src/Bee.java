public class Bee extends Animal{
    public static void eat() {
        System.out.println("Bees drink nectar...");
    }
        public static void sleep(){
            System.out.println("I sleep in my hive");
        }
        public static void move(){
            System.out.println("I fly");
        }
    }
