public class Orangutan extends Animal {
    public static void eat(){
        System.out.println("Orangutans eat fruit...");
    }
    public static void move(){
        System.out.println("I swing");
    }
    }
