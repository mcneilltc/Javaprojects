public class Bear extends Animal {

        public static void eat(){
            System.out.println("Bears eat fish...");
        }
    public static void sleep() {
        System.out.println("I sleep in a cave");
    }
    public static void move(){
        System.out.println("I charge");
    }
    }
