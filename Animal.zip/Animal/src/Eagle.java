public class Eagle extends Animal {
    public static void eat(){
        System.out.println("Eagles eat meat...");
    }
    public static void sleep() {
        System.out.println("I sleep in a tree");
    }
    public static void move(){
        System.out.println("I fly");
    }
}
