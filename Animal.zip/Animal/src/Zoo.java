public class Zoo {
    public static void main(String[] args) {

//        Animal animal1 = new Animal("some kingdom", "some phylum",
//                "some class", "some order", "some fam",
//                "some genus", "some species");
        Animal.eat();
        Animal.move();
        Animal.sleep();
        Bear.eat();
        Bear.sleep();
        Bear.move();
        Bee.eat();
        Bee.move();
        Bee.sleep();
        Eagle.eat();
        Eagle.sleep();
        Eagle.move();
        Gazelle.eat();
        Gazelle.sleep();
        Gazelle.move();
        Horse.eat();
        Horse.move();
        Horse.sleep();
        Jellyfish.eat();
        Jellyfish.move();
        Jellyfish.sleep();
        Orangutan.eat();
        Orangutan.sleep();
        Orangutan.move();
        Tiger.eat();
        Tiger.sleep();
        Tiger.move();
        Tigershark.eat();
        Tigershark.move();
        Tigershark.sleep();
        Turtle.eat();
        Turtle.move();
        Turtle.sleep();

//        Bear griz1= new Bear("Animalia", "Chordata",
//               "Mammalia", "Carnivora", "Ursidae",
//               "Ursus", "Ursidae grizzly");
//       griz1.eat();

//        Bee bee1 = new Bee("Animalia", "Arthropoda",
//                "Insecta", "Hymenoptera", "Apidae",
//                "Apis", " Apis Honey Bee");
//
//        Eagle eagle1 = new Eagle("Animalia", "Chordata",
//                "Aves", "Falconiformes", "Accipitridae",
//                "Heiraatus", "Hieraatus Spilogaster");
//
//        Gazelle gazelle1 = new Gazelle("Animalia", "Chordata",
//                "Mammalia", "Artiodactyla", "Giraffidae",
//                "Giraffa", "Giraffa camelopardialis");
//
//        Horse horse1 = new Horse("Animalia", "Chordata",
//                "Mammalia", "Perissodactyla", "Equidae",
//                "Equus", "Equus Caballus");
//
//        Jellyfish jelly1 = new Jellyfish("Animalia", "Cnidaria",
//                "Scyphozoa", "Semaeostomeae", "Cyaneidae",
//                "Cnidaria", "Cnidaria Scyphozoa Aurelia");
//
//        Orangutan orange1 = new Orangutan("Animalia", "Chordata",
//                "Mammalia", "Primates", "Hominidae",
//                "Pongo", "Pongo pygmaeus");
//
//        Tiger tiger1 = new Tiger("Animalia", "Chordata", "Mammalia",
//                "Carnivora", "Feliedae",
//                "Panthera", "Panthera tigris");
//
//        Tigershark jaws= new Tigershark("Animalia", "Chordata",
//                "Chondrichthyes", "Carcharhiniformes", "Carcharhinidae",
//                "Galeocerdo", "Caleocerdo Cuvier");
//
//        Turtle turbo1 = new Turtle("Animalia", "Chordata",
//                "Reptilia", "Testudines", "Testudinidae",
//                "Geochelone", "Geochelone Elegans");

    }
}
