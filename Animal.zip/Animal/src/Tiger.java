public class Tiger extends Animal {
    public static void eat(){
        System.out.println("Tigers eat meat...");
    }
    public static void sleep() {
        System.out.println("I sleep in a cave");
    }
    public static void move(){
        System.out.println("I run");
    }
    }
