public class Gazelle  extends Animal{
    public static void eat(){
        System.out.println("Giraffes eat leaves...");
    }
    public static void sleep() {
        System.out.println("I sleep standing");
    }
    public static void move(){
        System.out.println("I walk");
    }
}
