public class Animal {
//    String Kingdom;
//String Phylum;
//String Class;
//String Order;
//String Family;
//String Genus;
    public Animal(){
    }

public static void eat(){
        System.out.println("Eating food...");
}
public static void move(){
    System.out.println("I fly");
}
public static void sleep(){
    System.out.println("I sleep");
}

}
